#!/bin/sh
file=$1
eval ls
if [ ! -d $file ]
then 
	eval mkdir $file
fi

eval touch ./$file/file0.txt
eval touch ./$file/file1.txt
eval touch ./$file/file2.txt
eval touch ./$file/file3.txt
eval touch ./$file/file4.txt

eval mkdir -p ./$file/$file

eval cd $file

eval touch ./$file/file0.txt
eval touch ./$file/file1.txt
eval touch ./$file/file2.txt
eval touch ./$file/file3.txt
eval touch ./$file/file4.txt

eval cd $file
eval tar -cvf files.tar file0.txt file1.txt file2.txt file3.txt file4.txt

eval tar -xvf files.tar -C ./$file/$file
