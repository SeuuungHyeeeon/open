#!/bin/sh
t=$1
if [ ! -d $t ]
then
	eval mkdir $t
fi


eval touch $t/file0.txt

if [ ! -d $t/file0 ]
then
	eval mkdir -p ./$t/file0
fi

eval cd $t/file0
eval ln -s file0.txt file0.txt
eval cd


eval touch $t/file1.txt

if [ ! -d $t/file1 ]
then
	eval mkdir -p ./$t/file1
fi

eval cd $t/file1
eval ln -s file1.txt file1.txt
eval cd


eval touch $t/file2.txt

if [ ! -d $t/file2 ]
then
	eval mkdir -p ./$t/file2
fi

eval cd $t/file2
eval ln -s file2.txt file2.txt
eval cd


eval touch $t/file3.txt

if [ ! -d $t/file3 ]
then
	eval mkdir -p ./$t/file3
fi

eval cd $t/file3
eval ln -s file3.txt file3.txt
eval cd


eval touch $t/file4.txt

if [ ! -d $t/file4 ]
then
	eval mkdir -p ./$t/file4
fi

eval cd $t/file4
eval ln -s file4.txt file4.txt
eval cd
